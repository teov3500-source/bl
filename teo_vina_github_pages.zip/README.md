# Tèo Vina: Dấu Chân Cát Bụi

Để xuất bản game: upload `index.html` vào thư mục gốc repository GitHub, mở Settings → Pages → Deploy from a branch, chọn `main` và `/(root)`, rồi nhấn Save. Chờ GitHub Pages xuất bản URL để chia sẻ. Game cần Internet để tải thư viện Three.js từ CDN.
